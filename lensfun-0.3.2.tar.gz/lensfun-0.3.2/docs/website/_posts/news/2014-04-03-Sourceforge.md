---
title: Lensfun moved to Sourceforge!
layout: default
category: news
---

BerliOS will shut down its service at the end of April 2014. Therefore, we moved everything to Sourceforge and at the same time we took the opportunity to switch the version control system to git.

The new website can be found at 

[http://lensfun.sourceforge.net/](http://lensfun.sourceforge.net/)

and the project page is located at 

[http://sourceforge.net/p/lensfun](http://sourceforge.net/p/lensfun)


